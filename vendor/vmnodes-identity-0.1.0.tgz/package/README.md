# @vmnodes/identity

Verifies the identity token the VMnodes gateway injects into every request to
your app. Apps never handle passwords, sessions, or IdP integration.

```bash
npm install @vmnodes/identity
```

Until the first npm publish, the Builder Kit's starter
(`templates/starter/`) carries this package as a tarball pinned by its integrity
hash. That tarball is `npm pack` of this directory, not a second copy of the
code.

```ts
import { VmnodesIdentity } from "@vmnodes/identity";
// CommonJS works too: const { VmnodesIdentity } = require("@vmnodes/identity");

const identity = new VmnodesIdentity(); // reads VMNODES_PORTAL_URL, VMNODES_APP_ID
const user = await identity.currentUser(req.headers);
identity.requireRole(user, "approver");
```

The header contract is plain HTTP, so any language can do this: verify the RS256
JWT in `X-Vmnodes-Identity` against `<portal>/auth/jwks`, with issuer = the
portal URL and audience = your application id.

## Both environment variables are required

`VMNODES_PORTAL_URL` and `VMNODES_APP_ID` are injected by the platform when your
extension is installed. The constructor throws if either is missing, at start-up
rather than at the first request.

### `VMNODES_ISSUER_URL` (register A106 — interface split, no behaviour change yet)

The platform's neutral, cross-organisation token issuer host is not built yet
(register A106). Ahead of it, `VmnodesIdentity` already verifies `iss` and
fetches JWKS from `VMNODES_ISSUER_URL` when it is set, falling back to
`VMNODES_PORTAL_URL` (then the legacy `RUNBOX_PORTAL_URL`) when it is not.
Today the platform injects `VMNODES_ISSUER_URL` equal to `VMNODES_PORTAL_URL`,
so nothing observable changes yet. `VMNODES_PORTAL_URL` stays the value to
build a login link from — this package never reads it for verification once
`VMNODES_ISSUER_URL` is set.

`VMNODES_APP_ID` used to be optional, and that was a security defect (A62). See
the next section for why — it is not the reason you would guess.

**"Injected by the platform" means injected into the RUNNING CONTAINER.** Nothing
sets these in a CI runner, a local shell, or any other process outside the
installed application, so a release gate or script that constructs a
`VmnodesIdentity` must put them in its own environment by name — alongside the
token, which people remember, because it is the one that is obviously a secret.
The platform's own injected names are `VMNODES_API_URL`, `VMNODES_APP_ID`,
`VMNODES_APP_NAME`, `VMNODES_PORTAL_URL` and `VMNODES_PUBLISH_TOKEN`
(`extension-impl.ts`), plus `VMNODES_ENVIRONMENT` at deploy. **There is no
`VMNODES_CP_URL`** — if a gate reads that name, it is the gate's own convention
and nothing on this side will ever fill it.

## `issuer` and `audience` are PRESENCE checks, not just value checks

This is the part worth reading even if you are writing your own verifier in
another language, because it is a property of the JWT libraries rather than of
this SDK, and it is the opposite of what the option names suggest.

In `jose`, passing `issuer` to `jwtVerify` does **not** only mean "if there is an
`iss` claim, it must equal this". It adds `iss` to the set of claims that must be
**present at all**. From `jose`'s own `jwt_claims_set.js`:

```js
if (audience !== undefined) presenceCheck.push('aud');
if (issuer   !== undefined) presenceCheck.push('iss');
for (const claim of new Set(presenceCheck.reverse())) {
  if (!(claim in payload)) throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, ...);
}
```

The consequence runs the other way and is easy to miss: **omitting the option
does not weaken the check, it deletes it.** A verifier that leaves `audience` out
is not being lenient about which audience it accepts — it is accepting tokens
with no audience whatsoever, and tokens addressed to somebody else.

That is exactly what A62 was. The SDK had:

```ts
...(this.appId ? { audience: this.appId } : {})   // WRONG
```

which reads like a tidy optional. With `VMNODES_APP_ID` unset, an identity token
minted for **any other application on the same portal** verified here — same
signing key, same issuer, real user, valid signature, unexpired. On a shared
portal that is not an exotic input; it is the gateway's ordinary output for every
neighbouring app. Meanwhile every log line said the request was authenticated.

If you write your own verifier: always pass both, and never make either
conditional on configuration being present. Make the configuration required
instead.

## 401 and 503 are different answers

`currentUser` throws `IdentityError`, and `.status` distinguishes two things that
every version of this SDK before 2026-09-14 collapsed into one:

| status | meaning | what the caller should do |
| --- | --- | --- |
| `401` | We reached a verdict and the identity lost — bad signature, expired, wrong audience, wrong issuer, malformed. | Sign in again. |
| `503` | We never reached a verdict. The portal's key set was unreachable, timed out, or was unusable. | Nothing. Wait, or look at the platform status. |

Reporting the second as a 401 produces a loop that is invisible from your logs:
the user signs in again, receives a perfectly good fresh token, and is refused
again, while your log fills with tidy authentication failures and the actual
outage is never mentioned. The single largest case is not even a JOSE error — an
unreachable portal host rejects the JWKS fetch with a plain
`TypeError: fetch failed`, no `code`, not a `JOSEError`.

Use `identityFailureStatus(err)` if you catch `jose` errors yourself somewhere
else; it is exported so you do not end up maintaining a second copy of the list
that has to stay in step with this one.

The classification defaults to **503** for anything it does not recognise. This
costs no safety — both codes refuse the request — and saying "your credential is
bad" on the strength of an error we could not interpret is a claim we have not
earned.

## Application authorisation is still yours

`requireRole` and `requireGroup` throw `IdentityError(403)`. They are
conveniences over the claims in the token; deciding what a role may do stays in
your app (dev rule 5 — authentication and application authorisation are
separate).

## ADR-015 transition

The legacy `X-Runbox-Identity` header, the `RUNBOX_*` environment spellings and
the `RunBoxIdentity` class name still work and are deprecated. New code should
use the `Vmnodes` spellings.

## Changing this package: re-pack the Builder Kit's copy

`templates/builder-kit/starter/vendor/` carries this package as a tarball until
it is on npm. `tests/unit/builder-kit-vendor.test.ts` fails when the SDK source
and that tarball disagree. `templates/web/vendor/` carries a second copy, since a
Docker build context cannot reach outside its own directory, and
`tests/unit/vendored-identity-copies.test.ts` fails unless every copy under
`templates/` is byte-identical to the starter's. After any change here, run from
the repository root:

```bash
node packages/identity-sdk/build.mjs
cd packages/identity-sdk && npm pack --pack-destination ../../templates/builder-kit/starter/vendor
cd ../../templates/builder-kit/starter && npm install && npm test
cd ../../.. && cp templates/builder-kit/starter/vendor/vmnodes-identity-*.tgz templates/web/vendor/
```

The `npm install` step regenerates `package-lock.json`'s integrity hash. Without
it, `npm ci` refuses the new tarball on a clean machine. `templates/web` has no
lockfile, so the copy is all it needs. If the version changed, remove the old
tarball from both `vendor/` directories and update `templates/web/package.json`'s
`file:` path.
